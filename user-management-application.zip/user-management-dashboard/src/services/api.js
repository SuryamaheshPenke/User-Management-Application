import axios from "axios";

const BASE_URL = "http://localhost:5000/users";

export const fetchUsers = () => axios.get(BASE_URL);

export const addUser = (id, userData) => axios.post(BASE_URL, userData);

export const editUser = (id, userData) =>
  axios.put(`${BASE_URL}/${id}`, userData);

export const deleteUser = (id) => axios.delete(`${BASE_URL}/${id}`);
