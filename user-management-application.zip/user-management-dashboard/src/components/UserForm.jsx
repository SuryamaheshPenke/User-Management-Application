import React, { useState } from "react";
import { addUser, editUser } from "../services/api";

const UserForm = ({ user, onClose, onSave }) => {
  const [formData, setFormData] = useState({
    id: user.id || null,
    firstName: user.firstName || "",
    lastName: user.lastName || "",
    email: user.email || "",
    department: user.department || "",
  });

  const handleSubmit = (e) => {
    e.preventDefault();

    if (
      !formData.firstName.trim() ||
      !formData.lastName.trim() ||
      !formData.email.trim() ||
      !formData.department.trim()
    ) {
      alert("All fields are required. Please fill out all fields.");
      return;
    }

    const apiCall = formData.id ? editUser : addUser;

    const payload = {
      firstName: formData.firstName.trim(),
      lastName: formData.lastName.trim(),
      email: formData.email.trim(),
      department: formData.department.trim(),
    };

    if (formData.id) {
      payload.id = formData.id;
    }

    apiCall(formData.id, payload)
      .then((response) => {
        onSave(response.data);
      })
      .catch((error) => {
        console.error("Failed to save user:", error);
        alert("Failed to save user. Please try again.");
      });
  };

  return (
<div className="card p-3 mb-3">
  <h3 className="text-center mb-4">{formData.id ? "Edit User" : "Add User"}</h3>
  <form onSubmit={handleSubmit}>
    <div className="row">
      <div className="col-12 col-md-6 mb-3">
        <label className="form-label">First Name</label>
        <input
          type="text"
          className="form-control"
          value={formData.firstName}
          onChange={(e) =>
            setFormData({ ...formData, firstName: e.target.value })
          }
          required
        />
      </div>
      <div className="col-12 col-md-6 mb-3">
        <label className="form-label">Last Name</label>
        <input
          type="text"
          className="form-control"
          value={formData.lastName}
          onChange={(e) =>
            setFormData({ ...formData, lastName: e.target.value })
          }
          required
        />
      </div>
      <div className="col-12 col-md-6 mb-3">
        <label className="form-label">Email</label>
        <input
          type="email"
          className="form-control"
          value={formData.email}
          onChange={(e) =>
            setFormData({ ...formData, email: e.target.value })
          }
          required
        />
      </div>
      <div className="col-12 col-md-6 mb-3">
        <label className="form-label">Department</label>
        <input
          type="text"
          className="form-control"
          value={formData.department}
          onChange={(e) =>
            setFormData({ ...formData, department: e.target.value })
          }
          required
        />
      </div>
    </div>
    <div className="d-flex justify-content-between flex-column flex-md-row">
      <button type="submit" className="btn btn-success w-100 w-md-45 mb-2 mb-md-0">
        Save
      </button>
      <button
        type="button"
        className="btn btn-secondary w-100 w-md-45"
        onClick={onClose}
      >
        Cancel
      </button>
    </div>
  </form>
</div>


  );
};

export default UserForm;
