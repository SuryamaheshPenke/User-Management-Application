import React, { useState, useEffect } from "react";
import { fetchUsers, deleteUser } from "../services/api";
import UserForm from "./UserForm";

const UserList = () => {
  const [users, setUsers] = useState([]);
  const [selectedUser, setSelectedUser] = useState(null);

  useEffect(() => {
    fetchUsers()
      .then((response) => setUsers(response.data))
      .catch((error) => alert("Failed to fetch users: " + error.message));
  }, [selectedUser]);

  const handleDelete = (id) => {
    deleteUser(id)
      .then(() => setUsers(users.filter((user) => user.id !== id)))
      .catch((error) => alert("Failed to delete user: " + error.message));
  };

  return (
    <div>
  <button
    className="btn btn-primary mb-3 w-100"
    onClick={() => setSelectedUser({})}
  >
    Add User
  </button>
  {selectedUser && (
    <UserForm
      user={selectedUser}
      onClose={() => setSelectedUser(null)}
      onSave={(newUser) => {
        if (newUser.id) {
          setUsers(users.map((u) => (u.id === newUser.id ? newUser : u)));
        } else {
          setUsers([...users, { ...newUser, id: users.length + 1 }]);
        }
        setSelectedUser(null);
      }}
    />
  )}
  
  <div className="row">
    {users.map((user) => (
      <div className="col-12 col-md-6 col-lg-4 mb-4" key={user.id}>
        <div className="card p-3">
          <h5 className="card-title">{user.firstName} {user.lastName}</h5>
          <p className="card-text">Email: {user.email}</p>
          <p className="card-text">Department: {user.department || "N/A"}</p>
          <div className="d-flex justify-content-between">
            <button
              className="btn btn-warning btn-sm"
              onClick={() => setSelectedUser(user)}
            >
              Edit
            </button>
            <button
              className="btn btn-danger btn-sm"
              onClick={() => handleDelete(user.id)}
            >
              Delete
            </button>
          </div>
        </div>
      </div>
    ))}
  </div>
</div>


  );
};

export default UserList;
