const express = require("express");
const bodyParser = require("body-parser");
const cors = require("cors");

const app = express();
const PORT = 5000;

app.use(cors());
app.use(bodyParser.json());

let users = [
  { id: 1, firstName: "John", lastName: "Doe", email: "john.doe@example.com", department: "IT" },
  { id: 2, firstName: "Jane", lastName: "Smith", email: "jane.smith@example.com", department: "HR" },
];



app.get("/users", (req, res) => {
  res.json(users);
});


app.get("/users/:id", (req, res) => {
  const user = users.find((u) => u.id === parseInt(req.params.id));
  if (!user) {
    return res.status(404).json({ message: "User not found" });
  }
  res.json(user);
});


app.post("/users", (req, res) => {
  const { firstName, lastName, email, department } = req.body;

  if (!firstName || !lastName || !email || !department) {
    return res.status(400).json({ message: "All fields are required" });
  }

  const newUser = {
    firstName,
    id: Math.floor(Math.random() * 1000000), 
    lastName,
    email,
    department,
  };

  users.push(newUser);
  res.status(201).json(newUser);
});


app.put("/users/:id", (req, res) => {
  const { id } = req.params;
  const { firstName, lastName, email, department } = req.body;

  const userIndex = users.findIndex((u) => u.id === parseInt(id));
  if (userIndex === -1) {
    return res.status(404).json({ message: "User not found" });
  }

  users[userIndex] = {
    id: parseInt(id),
    firstName: firstName || users[userIndex].firstName,
    lastName: lastName || users[userIndex].lastName,
    email: email || users[userIndex].email,
    department: department || users[userIndex].department,
  };

  res.json(users[userIndex]);
});

app.delete("/users/:id", (req, res) => {
  const { id } = req.params;

  const userIndex = users.findIndex((u) => u.id === parseInt(id));
  if (userIndex === -1) {
    return res.status(404).json({ message: "User not found" });
  }

  const deletedUser = users.splice(userIndex, 1);
  res.json(deletedUser);
});


app.listen(PORT, () => {
  console.log(`Server is running on http://localhost:${PORT}`);
});
